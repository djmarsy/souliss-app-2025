plugins {
  id("com.android.library")
  kotlin("android")
}
android {
  namespace = "it.souliss.next.network"
  compileSdk = 35
  defaultConfig { minSdk = 26 }
}
dependencies {
  implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}

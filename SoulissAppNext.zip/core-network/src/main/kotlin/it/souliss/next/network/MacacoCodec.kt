package it.souliss.next.network

object MacacoCodec {
  /**
   * Wire format (indicativo): [LEN][FC][...header...][payload].
   * TODO: completare in base alle specifiche/pcap; qui forniamo solo un PING minimalista.
   */
  fun encode(f: MacacoFrame): ByteArray {
    return when (f.function) {
      0x08 -> byteArrayOf(0x02, 0x08) // PING request: len=2, fc=0x08 (placeholder)
      else -> byteArrayOf()
    }
  }

  fun decode(b: ByteArray): MacacoFrame? {
    if (b.isEmpty()) return null
    val fc = b.getOrNull(1)?.toInt() ?: return null
    return MacacoFrame(function = fc, payload = b.drop(2).toByteArray())
  }
}

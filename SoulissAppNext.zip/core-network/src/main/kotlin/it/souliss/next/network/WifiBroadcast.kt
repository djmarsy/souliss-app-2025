package it.souliss.next.network

import android.content.Context
import android.net.wifi.WifiManager

class WifiBroadcast(private val context: Context) {
  private var lock: WifiManager.MulticastLock? = null
  fun acquire() {
    val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    lock = wm.createMulticastLock("souliss-next").apply { setReferenceCounted(true); acquire() }
  }
  fun release() { lock?.let { if (it.isHeld) it.release() } }
}

package it.souliss.next.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.SocketTimeoutException

/** UDP socket for Souliss vNet over IP (default port 230). */
class VNetSocket(private val localPort: Int = 0, private val timeoutMs: Int = 1200) : AutoCloseable {
  private val socket = DatagramSocket(localPort).apply { soTimeout = timeoutMs }
  val defaultPort: Int = 230

  suspend fun send(data: ByteArray, host: String, port: Int = defaultPort) = withContext(Dispatchers.IO) {
    val addr = InetAddress.getByName(host)
    socket.send(DatagramPacket(data, data.size, InetSocketAddress(addr, port)))
  }

  suspend fun broadcast(data: ByteArray, broadcast: String = "255.255.255.255", port: Int = defaultPort) =
    withContext(Dispatchers.IO) {
      socket.broadcast = true
      socket.send(DatagramPacket(data, data.size, InetAddress.getByName(broadcast), port))
    }

  suspend fun receive(max: Int = 1500): ByteArray? = withContext(Dispatchers.IO) {
    val buf = ByteArray(max)
    val pkt = DatagramPacket(buf, buf.size)
    try { socket.receive(pkt); buf.copyOf(pkt.length) } catch (e: SocketTimeoutException) { null }
  }

  override fun close() { socket.close() }
}

package it.souliss.next.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class DiscoveryClient(private val socket: VNetSocket) {
  /** Broadcast di "Gateway Discover" (fc 0x28) — frame placeholder. */
  suspend fun discoverGateways(): List<ByteArray> = withContext(Dispatchers.IO) {
    val discover = byteArrayOf(0x02, 0x28) // len=2, fc=0x28 (placeholder)
    socket.broadcast(discover)
    val found = mutableListOf<ByteArray>()
    repeat(4) { socket.receive()?.let(found::add) }
    found
  }
}

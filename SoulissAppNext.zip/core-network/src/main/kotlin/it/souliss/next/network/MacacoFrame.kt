package it.souliss.next.network

/** Minimal frame model; values and layout to be completed per MaCaco/vNet spec. */
data class MacacoFrame(
  val function: Int,
  val payload: ByteArray = byteArrayOf(),
  val srcNode: Int = 0,
  val dstNode: Int = 0,
) {
  fun toBytes(): ByteArray = MacacoCodec.encode(this)
  companion object { fun fromBytes(b: ByteArray) = MacacoCodec.decode(b) }
}

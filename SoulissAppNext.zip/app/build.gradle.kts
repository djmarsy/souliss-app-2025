plugins {
  id("com.android.application")
  kotlin("android")
  id("com.google.dagger.hilt.android")
}
android {
  namespace = "it.souliss.next"
  compileSdk = 35
  defaultConfig {
    applicationId = "it.souliss.next"
    minSdk = 26
    targetSdk = 35
    versionCode = 1
    versionName = "0.1.0"
  }
  buildFeatures { compose = true }
  composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
  packaging { resources.excludes += setOf("META-INF/AL2.0", "META-INF/LGPL2.1") }
  signingConfigs {
    create("release") {
      storeFile = file(project.properties["SOULISS_STORE_FILE"] as String? ?: "keystore.jks")
      storePassword = (project.properties["SOULISS_STORE_PASSWORD"] as String?) ?: ""
      keyAlias = (project.properties["SOULISS_KEY_ALIAS"] as String?) ?: "soulissapp"
      keyPassword = (project.properties["SOULISS_KEY_PASSWORD"] as String?) ?: ""
    }
  }
  buildTypes {
    getByName("release") {
      isMinifyEnabled = true
      proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
      signingConfig = signingConfigs.getByName("release")
    }
    getByName("debug") { isMinifyEnabled = false }
  }
  splits {
    abi {
      isEnable = true
      isUniversalApk = true
      reset()
      include("armeabi-v7a", "arm64-v8a", "x86", "x86_64")
    }
  }
}
dependencies {
  implementation(project(":core-network"))
  implementation(project(":core-data"))

  val composeBom = platform("androidx.compose:compose-bom:2024.09.01")
  implementation(composeBom)
  androidTestImplementation(composeBom)

  implementation("androidx.activity:activity-compose:1.9.2")
  implementation("androidx.compose.material3:material3")
  implementation("androidx.compose.ui:ui")
  implementation("androidx.compose.ui:ui-tooling-preview")
  debugImplementation("androidx.compose.ui:ui-tooling")
  implementation("androidx.navigation:navigation-compose:2.8.0")

  implementation("androidx.hilt:hilt-navigation-compose:1.2.0")
  implementation("com.google.dagger:hilt-android:2.52")
  kapt("com.google.dagger:hilt-compiler:2.52")

  implementation("androidx.room:room-runtime:2.6.1")
  implementation("androidx.room:room-ktx:2.6.1")
  kapt("androidx.room:room-compiler:2.6.1")

  implementation("androidx.work:work-runtime-ktx:2.9.1")
  implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.2")
  implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}

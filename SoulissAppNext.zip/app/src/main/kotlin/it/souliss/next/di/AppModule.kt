package it.souliss.next.di

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton
import it.souliss.next.network.VNetSocket
import it.souliss.next.network.DiscoveryClient
import it.souliss.next.data.repo.DevicesRepository

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
  @Provides @Singleton fun provideSocket(): VNetSocket = VNetSocket()
  @Provides @Singleton fun provideDiscovery(socket: VNetSocket) = DiscoveryClient(socket)
  @Provides @Singleton fun provideRepo(socket: VNetSocket) = DevicesRepository(socket)
}

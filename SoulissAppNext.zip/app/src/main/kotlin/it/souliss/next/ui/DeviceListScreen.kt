package it.souliss.next.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class UiDevice(val name: String, val typical: String, val state: String)

@Composable
fun DeviceListScreen(modifier: Modifier = Modifier) {
  val demo = listOf(
    UiDevice("Lampada Soggiorno", typical = "T11", state = "OFF"),
    UiDevice("Striscia RGB", typical = "T16", state = "#FF8800"),
  )
  LazyColumn(modifier = modifier.fillMaxSize()) {
    items(demo) { d -> DeviceRow(d) }
  }
}

@Composable
fun DeviceRow(d: UiDevice) {
  Card(modifier = Modifier
    .fillMaxWidth()
    .padding(12.dp)) {
    Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
      Column {
        Text(d.name, style = MaterialTheme.typography.titleMedium)
        Text(d.typical, style = MaterialTheme.typography.bodySmall)
      }
      Text(d.state, style = MaterialTheme.typography.labelLarge)
    }
  }
}

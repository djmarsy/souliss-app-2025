package it.souliss.next

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import dagger.hilt.android.HiltAndroidApp
import dagger.hilt.android.AndroidEntryPoint

@HiltAndroidApp
class SoulissApp : Application()

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContent { SoulissTheme { App() } }
  }
}

@Composable fun SoulissTheme(content: @Composable () -> Unit) {
  MaterialTheme(content = content)
}

@Composable fun App() {
  Scaffold(topBar = { TopAppBar(title = { Text("SoulissApp Next") }) }) { padd ->
    DeviceListScreen()
  }
}

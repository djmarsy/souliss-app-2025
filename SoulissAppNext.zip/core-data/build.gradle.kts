plugins {
  id("com.android.library")
  kotlin("android")
  id("com.google.dagger.hilt.android")
  kotlin("plugin.serialization")
}
android {
  namespace = "it.souliss.next.data"
  compileSdk = 35
  defaultConfig { minSdk = 26 }
}
dependencies {
  implementation("androidx.room:room-runtime:2.6.1")
  implementation("androidx.room:room-ktx:2.6.1")
  kapt("androidx.room:room-compiler:2.6.1")
  implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.2")
}

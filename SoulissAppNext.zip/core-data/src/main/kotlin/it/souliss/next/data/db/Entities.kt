package it.souliss.next.data.db

import androidx.room.*

@Entity(tableName = "devices")
data class DeviceEntity(
  @PrimaryKey val id: String,
  val name: String,
  val node: Int,
  val slot: Int,
  val typical: Int,
)

@Dao
interface DeviceDao {
  @Query("SELECT * FROM devices")
  suspend fun all(): List<DeviceEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertAll(items: List<DeviceEntity>)
}

@Database(entities = [DeviceEntity::class], version = 1)
abstract class AppDatabase : RoomDatabase() { abstract fun devices(): DeviceDao }

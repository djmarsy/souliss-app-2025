package it.souliss.next.data.repo

import it.souliss.next.network.MacacoFrame
import it.souliss.next.network.VNetSocket

class DevicesRepository(private val sock: VNetSocket) {
  suspend fun ping(host: String): Boolean {
    val req = MacacoFrame(function = 0x08).toBytes()
    sock.send(req, host)
    val resp = sock.receive()
    // 0x18 = Ping answer (placeholder check)
    return resp?.getOrNull(1)?.toInt() == 0x18
  }

  suspend fun toggleT11(host: String, node: Int, slot: Int, on: Boolean) {
    // TODO: comporre frame 0x14 (Force register value) su [node,slot]
    val fc = 0x14
    val payload = byteArrayOf() // node, slot, value
    val req = MacacoFrame(function = fc, payload = payload).toBytes()
    sock.send(req, host)
  }
}

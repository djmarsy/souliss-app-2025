package it.souliss.next.data.model

enum class Typical(val code: Int) {
  T11(0x11), // ON/OFF Digital Output
  T16(0x16), // RGB Light
  T31(0x31); // Thermostat
}

// settings.gradle.kts
rootProject.name = "SoulissAppNext"
include(":app", ":core-network", ":core-data")
